# Keep WebView JavaScript interfaces intact
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep the app's own classes
-keep class com.cmdsoft.hotelpos.** { *; }

# WebView
-keepclassmembers class android.webkit.** { *; }

# Suppress warnings for unused code
-dontwarn okhttp3.**
-dontwarn okio.**
